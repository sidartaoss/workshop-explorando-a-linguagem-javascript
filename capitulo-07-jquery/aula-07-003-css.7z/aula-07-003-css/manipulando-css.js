/**
 * Aula 07.003. CSS
 * 
 * 1. Olha a ideia que o instrutor teve agora para nos explicar a respeito de como a gente consegue manipular no CSS da pagina atraves do jQuery.
 * 
 * 2. Okay? Nos vamos usar o mesmo exemplo que a gente fez na aula passada, so que nos vamos lidar tambem com outros dois arquivos, mas a ideia eh a seguinte: eu quero que, ao selecionar um checkbox, eu quero alterar a cor da fonte desta linha, entao, o Ricardo, aqui, e esse e-mail, tem que ficar com outra cor. Ai, selecionei a linha debaixo, tem que ficar de outra cor, desmarquei, a linha volta ao normal, fica preto, selecionei de volta, fica azul, desmarquei, fica preto novamente.
 * 
 * 3. Entao, olha so, o instrutor criou um arquivo style.css, e criou a classe selecionado, 
 * 
 * .selecionado {
 *      color: blue; 
 * }
 * 
 * , e, aqui, no index.html, nos estamos referenciando o style.css, 
 * 
 * <link rel="stylesheet" href="style.css">
 * 
 * , e, ai, eu movi para la o body,
 * 
 * body {
 *      padding: 20px;
 * }
 * 
 * 4. E, aqui, no index.html, eu mudei o nome do arquivo Javascript,
 * 
 * <script src="manipulando-css.js"></script>
 * 
 * 5. O resto esta igualzinho. Okay? E, ai, so para nos vermos como eh que tem que ficar, se nos inspecionarmos esse elemento aqui, no Chrome DevTools, por exemplo, aqui, na linha do Ricardo, botao direito, Add attribute, o que eu quero eh que, no tr, eu quero adicionar no tr aqui, eu vou adicionar um atributo class, e vai ser a classe 'selecionado', eh isso que eu quero, ou seja, a linha inteira vai ficar azul.
 * 
 * 6. Ou seja, quando eu clicar, eu quero adicionar essa classe 'selecionado' ao tr. Quando eu clicar aqui, oh, nesse input checkbox. Entao, o instrutor ja vai nos mostrar algumas coisas tambem de seletores, a gente nao deixa de trabalhar com seletores, entao, o instrutor vai nos mostrar como eh que nos selecionamos um elemento para cima, aqui, tambem, eh isso que nos queremos fazer, entao.
 * 
 * 7. Ao desmarcar o checkbox, o que eu quero eh apagar a classe 'selecionado' do elemento tr. Ai, eh para voltar ao estilo normal.
 * 
 * 8. Pegou a ideia?
 * 
 * 9. Entao, vamos la, vamos comecar implementando, aqui, do mais simples, e, depois, a gente vai melhorando, aos poucos, ai.
 * 
 * 10. Entao, olha so, o que nos vamos fazer, a primeira coisa que nos vamos fazer aqui eh, quando eu clicar aqui, no checkbox, por exemplo, de Ricardo, qual eh o evento Javascript que eh lancado? Eh o evento change.
 * 
 * 11. Entao, o selecaoUsuarios.on('change'), ou seja, o evento mudou alguma coisa, ele vai cair, aqui, para mim, vai executar essa funcao aqui,
 * 
 * selecaoUsuarios.on('change', function () {
 *      
 * });
 * 
 * , okay? 
 * 
 * 12. E, aqui, vai ser importante eu pegar o evento que ele lanca,
 * 
 * selecaoUsuarios.on('change', function (evento) {
 *      
 * });
 * 
 * 13. O instrutor vai nos exmplicar por que. Vamos dar o log aqui no evento,
 * 
 * selecaoUsuarios.on('change', function () {
 *      console.log('evento', evento)
 * });
 * 
 */

 $(function () {

    var selecaoTodosUsuarios = $('#selecao-todos-usuarios');
    var selecaoUsuarios = $('.js-selecao-usuario');

    selecaoUsuarios.on('click', function() {
        var totalUsuariosSelecionados = $('.js-selecao-usuario:checked').length;
        var checked = selecaoUsuarios.length === totalUsuariosSelecionados;
        selecaoTodosUsuarios.prop('checked', checked);
    });

    selecaoTodosUsuarios.on('click', function() {
         selecaoUsuarios.prop('checked', selecaoTodosUsuarios.prop('checked'));
    });    

    selecaoUsuarios.on('change', function (evento) {
        console.log('evento', evento)
    });

 });

